from flask import Flask, jsonify, request, render_template
import numpy as np
import joblib
#from sklearn.externals import joblib
import pandas as pd
import numpy as np
from sklearn import linear_model
#from sklearn.externals import joblib
from bs4 import BeautifulSoup
import re
from sklearn.feature_extraction.text import CountVectorizer

import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from werkzeug.utils import secure_filename



# https://www.tutorialspoint.com/flask
import flask
app = Flask(__name__)


###################################################
from datetime import datetime

def add_custom_features(p_insurance):
    #str_date = p_insurance['Original_Quote_Date']
    year_lst=[]
    month_lst=[]
    weekend_lst=[]
    #date_lst=[]

    p_insurance['Original_Quote_Date'] = pd.to_datetime(p_insurance['Original_Quote_Date'])

    year = pd.DatetimeIndex(p_insurance['Original_Quote_Date']).year
    month = pd.DatetimeIndex(p_insurance['Original_Quote_Date']).month
    #day = pd.DatetimeIndex(p_insurance['Original_Quote_Date']).day
    year_lst = list(year)
    month_lst = list(month)
    #date_lst = list(day)

    #weekend_df = pd.DataFrame()
    p_insurance['Is_Weekend'] = p_insurance['Original_Quote_Date'].dt.weekday > 4
    p_insurance['Is_Weekend'] = p_insurance['Is_Weekend'].astype(int)

    '''for i in str_date:
        print(i)
        year_lst.append(int(i[0:4]))
        month_lst.append(int(i[5:7]))
        date_lst.append(int(i[8:]))
        d = datetime(int(i[0:4]), int(i[5:7]), int(i[8:]))
        if d.weekday() > 4:
            weekend_lst.append(1)
        else:
            weekend_lst.append(0)'''

    p_insurance['Year'] = year_lst
    p_insurance['Month'] = month_lst
    #p_insurance['Is_Weekend'] = weekend_lst

    p_insurance.drop(['Original_Quote_Date'], axis = 1, inplace = True)

    p_insurance["Quarter"] = pd.cut(p_insurance["Month"], bins=[0., 3.0, 6.0, 9.0, 12.0, np.inf], labels=[1, 2, 3, 4, 5])
    p_insurance['Quarter'] = p_insurance['Quarter'].astype(int)

    return p_insurance
	
def replace_y_and_n_with_one_and_zero(p_insurance):
    cols = p_insurance.columns
    numerical_cols = p_insurance._get_numeric_data().columns
    categorical_features = sorted(list(set(cols) - set(numerical_cols)))

    two_value_features = list(p_insurance[categorical_features].nunique().index[p_insurance[categorical_features].nunique().values==2])
    three_value_features = list(p_insurance[categorical_features].nunique().index[p_insurance[categorical_features].nunique().values==3])
    for i in two_value_features:
        p_insurance[i].replace({'Y' : 1, 'N' : 0}, inplace = True)

    for j in three_value_features:
        p_insurance[j].replace({'Y' : 1, 'N' : 0, ' ' : np.nan}, inplace = True)
    return p_insurance
	
def replace_minus_one_with_nan(p_insurance):
    for nanCol in p_insurance:
        p_insurance[nanCol].replace({-1 : np.nan}, inplace = True)
    return p_insurance
	
def remove_comma(p_insurance):
    cols = p_insurance.columns
    numerical_cols = p_insurance._get_numeric_data().columns

    categorical_features = sorted(list(set(cols) - set(numerical_cols)))

    for col in categorical_features:
        if(p_insurance[col].str.contains(",").any() == True):
            print(col)
            p_insurance[col] = p_insurance[col].str.replace(",","").astype(int)
    return p_insurance
###################################################


@app.route('/')
def hello_world():
    return 'Hello World!'

@app.route('/home')
def ch_box():
    return flask.render_template('home.html')

@app.route('/call_method', methods=['POST'])
def call_method():
    #return flask.render_template('predict_result.html') if request.form.get('quoteNum') else flask.render_template('index.html')
    if request.form.get('quoteNum'):
        return flask.render_template('predict_result.html')
    elif request.form.get('fileUpd'):
        return flask.render_template('index.html')
    elif request.form.get('gitUpd'):
        return flask.render_template('git_upload.html')

@app.route('/index')
def index():
    return flask.render_template('index.html')
	
@app.route('/git', methods=['POST'])
def git():
    print('inside the git method!')
    uploaded_file = request.form['git_url']
    print('GIT URL is:{0}'.format(uploaded_file))
    clf = joblib.load('final_model.pkl')
    #url = 'https://media.githubusercontent.com/media/srikanth-gk/quoted_insurance/master/train.csv'
    #response = requests.get(url)
    #tst_url = 'https://media.githubusercontent.com/media/srikanth-gk/quoted_insurance/master/test.csv'
    print('***********')
    #uploaded_file = request.files['uploaded_csv_file']
    uploaded_df = pd.read_csv(uploaded_file)
    final_df['QuoteNumber'] = uploaded_df['QuoteNumber']

    #insurance_tst = pd.read_csv(tst_file)
    ins_uploaded = uploaded_df.copy()
	
    ins_uploaded = add_custom_features(ins_uploaded)
    ins_uploaded = replace_y_and_n_with_one_and_zero(ins_uploaded)
    ins_uploaded = replace_minus_one_with_nan(ins_uploaded)

    numeric_attribs = ins_uploaded._get_numeric_data().columns

    categorical_attribs = ins_uploaded[sorted(list(set(ins_uploaded.columns) - set(ins_uploaded._get_numeric_data().columns)))].columns

    num_attribs = list(numeric_attribs)
    cat_attribs = list(categorical_attribs)

    ins_uploaded = remove_comma(ins_uploaded)

    tst_transform = joblib.load('full_pipeline.pkl')
    tst_prepared_new = tst_transform.transform(ins_uploaded)
    final_df['Prediction'] = list(clf.predict(tst_prepared_new))
    #final_df['Probability'] = list(clf.predict_proba(tst_prepared_new).round(2)*100)
    final_df['Probability'] = list((np.amax(clf.predict_proba(tst_prepared_new), axis=1)).round(2)*100)
    print(final_df.head())

    '''num_pipeline = Pipeline([('imputer', SimpleImputer(strategy="median")),('std_scaler', StandardScaler()),])

    full_pipeline_tst = ColumnTransformer([("num", num_pipeline, num_attribs),("cat", OneHotEncoder(handle_unknown="ignore"), cat_attribs,),])

    tst_before_transform = full_pipeline_tst.fit(ins_uploaded)

    tst_transform = joblib.load('full_pipeline.pkl')
    tst_transform.transform(tst_before_transform)'''

    #tst_prep_data = joblib.load('tst_prep.pkl')
    #to_predict_list = request.form.to_dict()
    #review_data = to_predict_list['review_data']
    #pred = clf.predict(tst_prep_data.transform([tst_prep_data]))
    return render_template('predict_result.html')	


@app.route('/predict', methods=['POST'])
def predict():
    clf = joblib.load('final_model.pkl')
    #url = 'https://media.githubusercontent.com/media/srikanth-gk/quoted_insurance/master/train.csv'
    #response = requests.get(url)
    #tst_url = 'https://media.githubusercontent.com/media/srikanth-gk/quoted_insurance/master/test.csv'
    print('***********')
    uploaded_file = request.files['uploaded_csv_file']
    uploaded_df = pd.read_csv(uploaded_file)
    final_df['QuoteNumber'] = uploaded_df['QuoteNumber']

    #insurance_tst = pd.read_csv(tst_file)
    ins_uploaded = uploaded_df.copy()
	
    ins_uploaded = add_custom_features(ins_uploaded)
    ins_uploaded = replace_y_and_n_with_one_and_zero(ins_uploaded)
    ins_uploaded = replace_minus_one_with_nan(ins_uploaded)

    numeric_attribs = ins_uploaded._get_numeric_data().columns

    categorical_attribs = ins_uploaded[sorted(list(set(ins_uploaded.columns) - set(ins_uploaded._get_numeric_data().columns)))].columns

    num_attribs = list(numeric_attribs)
    cat_attribs = list(categorical_attribs)

    ins_uploaded = remove_comma(ins_uploaded)

    tst_transform = joblib.load('full_pipeline.pkl')
    tst_prepared_new = tst_transform.transform(ins_uploaded)
    final_df['Prediction'] = list(clf.predict(tst_prepared_new))
    #final_df['Probability'] = list(clf.predict_proba(tst_prepared_new).round(2)*100)
    final_df['Probability'] = list((np.amax(clf.predict_proba(tst_prepared_new), axis=1)).round(2)*100)
    print(final_df.head())

    '''num_pipeline = Pipeline([('imputer', SimpleImputer(strategy="median")),('std_scaler', StandardScaler()),])

    full_pipeline_tst = ColumnTransformer([("num", num_pipeline, num_attribs),("cat", OneHotEncoder(handle_unknown="ignore"), cat_attribs,),])

    tst_before_transform = full_pipeline_tst.fit(ins_uploaded)

    tst_transform = joblib.load('full_pipeline.pkl')
    tst_transform.transform(tst_before_transform)'''

    #tst_prep_data = joblib.load('tst_prep.pkl')
    #to_predict_list = request.form.to_dict()
    #review_data = to_predict_list['review_data']
    #pred = clf.predict(tst_prep_data.transform([tst_prep_data]))
    return render_template('predict_result.html')

@app.route('/predict_result', methods=['POST'])
def predict_result():
    entered_qnumber = request.form.get('quote_number')
    print('Entered Quote Number is:{0}'.format(entered_qnumber))
    print('Final DF shape:{0}'.format(final_df.shape))
    #clf = joblib.load('final_model.pkl')
    #predicted_result = clf.predict(entered_qnumber)
    '''predicted_result = int(final_df[final_df['QuoteNumber']==int(entered_qnumber)]['Prediction'])
    probability_result = int(final_df[final_df['QuoteNumber']==int(entered_qnumber)]['Probability'])
    print('Prediction is:{0}'.format(predicted_result))
    print('Probability is:{0}'.format(probability_result))'''
    try:
        predicted_result = int(final_df[final_df['QuoteNumber']==int(entered_qnumber)]['Prediction'])
        probability_result = int(final_df[final_df['QuoteNumber']==int(entered_qnumber)]['Probability'])
        print('Prediction is:{0}'.format(predicted_result))
        print('Probability is:{0}'.format(probability_result))
        '''if predicted_result == 1:
            prediction = "Positive"
        else:
            prediction = "Negative"'''
    except:
        predicted_result = "Oops! The entered Quote Number does not exist. Please enter the correct Quote Number..."
        return render_template('error.html', err_result=predicted_result)
    #return jsonify({'Prediction': prediction})
    return render_template('output.html', pred_result=predicted_result, proba_result=probability_result)


if __name__ == '__main__':
    final_df = pd.DataFrame(columns=['QuoteNumber'])
    app.run(host='0.0.0.0', port=8080)
